<?php
/**
 * REST lexicon topic
 *
 * @language it
 * @package modx
 * @subpackage lexicon
 */
$_lang['error'] = 'Errore!';
$_lang['rest.err_class_remove'] = 'Si &egrave; verificato un errore durante il tentativo di rimuovere la [[+class_key]]';
$_lang['rest.err_class_save'] = 'Si &egrave; verificato un errore durante il tentativo di salvare la [[+class_key]]';
$_lang['rest.err_field_ns'] = '[[+field]] non specificato!';
$_lang['rest.err_field_required'] = 'Questo campo &egrave; obbligatorio.';
$_lang['rest.err_fields_required'] = 'I seguenti campi sono obbligatori: [[+fields]]';
$_lang['rest.err_obj_nf'] = '[[+class_key]] non trovata!';
