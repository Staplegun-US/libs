<?php
/**
 * Mail Czech lexicon topic
 *
 * @language cs
 * @package modx
 * @subpackage lexicon
 *
 * @author modxcms.cz
 * @updated 2011-10-23
 */
// $_lang['mail_err_address_ns'] = 'You must provide an email address to send to.';
$_lang['mail_err_address_ns'] = 'Cílová e-mailová adresa musí být vyplněna.';

// $_lang['mail_err_derive_getmailer'] = 'Attempt to call abstract function _getMailer() in modMail class. You must implement this function in a derivative of modMail.';
$_lang['mail_err_derive_getmailer'] = 'Pokus o zavolání abstraktní funkce _getMailer() ve třídě modMail. Musíte implementovat tuto funkci v odloučeninách modMail.';

// $_lang['mail_err_attr_nv'] = '[[+attr]] is not a valid PHPMailer attribute and is being ignored by the implementation.';
$_lang['mail_err_attr_nv'] = '[[+attr]] není platným atributem PHPMaileru a bude implementací ignorován.';

// $_lang['mail_err_unset_spec'] = 'modPHPMailer does not support unsetting specific addresses. Use reset() to clear all recipients and add back the ones you want to send to.';
$_lang['mail_err_unset_spec'] = 'modPHPMailer nepodporuje nenastavení dané adresy. Použijte reset() pro smazání všech příjemců a následně přidejte toho, kterého chcete.';
